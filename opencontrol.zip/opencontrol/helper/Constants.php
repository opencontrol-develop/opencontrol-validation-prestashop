<?php

class Constants
{
    const SETTINGS_NAME = 'opencontrol_settings';
    const SANDBOX_URL = 'https://sandbox-api.opencontrol.mx';
    const LIVE_URL = 'https://api.opencontrol.mx';
    const DEVICE_SESSION_URL = '/v1/logo.htm?m=%s&s=%s&u=%s&k=%s';
}