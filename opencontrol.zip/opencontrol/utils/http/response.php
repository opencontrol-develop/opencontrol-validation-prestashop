<?php

class Response{
    public $httpCode;
    public $body;
}