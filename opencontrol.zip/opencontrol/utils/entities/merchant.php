<?php

class OpencontrolMerchant
{
    const REQUIRED_FIELDS = [
        'id'
    ];
    
    public $id;
}