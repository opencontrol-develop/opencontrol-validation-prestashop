<?php

class OpencontrolCard
{
    const REQUIRED_FIELDS = [
        'number'
    ];
    
    public $number;
    public $holder_name;
}