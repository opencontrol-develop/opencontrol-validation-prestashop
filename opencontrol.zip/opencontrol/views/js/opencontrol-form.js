console.log("Opencontrol Form loaded");
console.log("UrlDeviceSessionId:{$urlDeviceSessionId}");